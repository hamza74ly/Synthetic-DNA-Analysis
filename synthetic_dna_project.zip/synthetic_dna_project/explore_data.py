import pandas as pd

def explore_data(file_path):
    df = pd.read_csv(file_path)
    print("\n--- Dataset Info ---")
    df.info()
    print("\n--- First 5 Rows ---")
    print(df.head())
    print("\n--- Basic Statistics ---")
    print(df.describe(include='all'))
    print("\n--- Missing Values ---")
    print(df.isnull().sum())

if __name__ == "__main__":
    explore_data("/home/ubuntu/upload/synthetic_dna_dataset.csv")

