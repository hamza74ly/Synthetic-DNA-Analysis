import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def eda_and_visualize(file_path):
    df = pd.read_csv(file_path)

    # Set style for plots
    sns.set_style("whitegrid")

    # 1. Distribution of GC_Content
    plt.figure(figsize=(10, 6))
    sns.histplot(df["GC_Content"], kde=True, bins=30)
    plt.title("Distribution of GC Content")
    plt.xlabel("GC Content")
    plt.ylabel("Frequency")
    plt.savefig("gc_content_distribution.png")
    plt.close()

    # 2. Relationship between GC_Content and Sequence_Length
    plt.figure(figsize=(10, 6))
    sns.scatterplot(x="GC_Content", y="Sequence_Length", data=df, hue="Mutation_Flag", palette="viridis")
    plt.title("GC Content vs. Sequence Length by Mutation Flag")
    plt.xlabel("GC Content")
    plt.ylabel("Sequence Length")
    plt.savefig("gc_sequence_length_scatter.png")
    plt.close()

    # 3. Count of each Class_Label
    plt.figure(figsize=(10, 6))
    sns.countplot(x="Class_Label", data=df, palette="pastel")
    plt.title("Count of Each Class Label")
    plt.xlabel("Class Label")
    plt.ylabel("Count")
    plt.savefig("class_label_count.png")
    plt.close()

    # 4. Disease Risk Distribution
    plt.figure(figsize=(8, 5))
    sns.countplot(x="Disease_Risk", data=df, palette="coolwarm", order=df["Disease_Risk"].value_counts().index)
    plt.title("Distribution of Disease Risk")
    plt.xlabel("Disease Risk")
    plt.ylabel("Count")
    plt.savefig("disease_risk_distribution.png")
    plt.close()

    print("Visualizations saved as PNG files.")

if __name__ == "__main__":
    eda_and_visualize("/home/ubuntu/upload/synthetic_dna_dataset.csv")

