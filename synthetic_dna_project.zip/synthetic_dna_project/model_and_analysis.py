import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

def model_and_analyze(file_path):
    df = pd.read_csv(file_path)

    # Separate features (X) and target (y)
    X = df.drop([col for col in df.columns if 'Disease_Risk' in col], axis=1) # Drop all Disease_Risk columns
    y = df[['Disease_Risk_Low', 'Disease_Risk_Medium']].idxmax(axis=1) # Reconstruct original Disease_Risk
    y = y.apply(lambda x: x.replace('Disease_Risk_', ''))
    y = y.replace({False: 'High'}) # Handle the case where both are False, meaning 'High'

    # Handle the case where the original 'Disease_Risk' column was dropped in cleaning, and we need to use the one-hot encoded columns.
    # We need to re-create a single target variable from the one-hot encoded columns.
    # Assuming 'Disease_Risk_Low', 'Disease_Risk_Medium' and the absence of both implies 'High'
    # This needs to be aligned with how the original 'Disease_Risk' was encoded.
    # Let's re-evaluate the target variable creation based on the cleaned data structure.

    # Re-read the cleaned data to ensure consistency
    df_cleaned = pd.read_csv("cleaned_synthetic_dna_dataset.csv")

    # Define features (X) and target (y)
    # The target variable 'Disease_Risk' was one-hot encoded into 'Disease_Risk_Low' and 'Disease_Risk_Medium'.
    # The third category 'High' is implied when both 'Low' and 'Medium' are False.
    # We need to convert these back to a single categorical target for classification.
    def get_disease_risk_label(row):
        if row['Disease_Risk_Low']:
            return 'Low'
        elif row['Disease_Risk_Medium']:
            return 'Medium'
        else:
            return 'High'

    df_cleaned['Disease_Risk_Label'] = df_cleaned.apply(get_disease_risk_label, axis=1)

    X = df_cleaned.drop(['Disease_Risk_Low', 'Disease_Risk_Medium', 'Disease_Risk_Label'], axis=1)
    y = df_cleaned['Disease_Risk_Label']

    # Split data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

    # Initialize and train a RandomForestClassifier model
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    # Make predictions
    y_pred = model.predict(X_test)

    # Evaluate the model
    accuracy = accuracy_score(y_test, y_pred)
    report = classification_report(y_test, y_pred)

    print(f"\n--- Model Accuracy: {accuracy:.4f} ---")
    print("\n--- Classification Report ---")
    print(report)

    # Feature Importance
    feature_importances = pd.Series(model.feature_importances_, index=X.columns).sort_values(ascending=False)
    print("\n--- Feature Importances ---")
    print(feature_importances)

if __name__ == "__main__":
    model_and_analyze("cleaned_synthetic_dna_dataset.csv")

