import pandas as pd

def clean_data(file_path):
    df = pd.read_csv(file_path)

    # Convert categorical columns to numerical using one-hot encoding
    df = pd.get_dummies(df, columns=['Class_Label', 'Disease_Risk'], drop_first=True)

    # Example of potential data transformation (if needed)
    # For instance, if 'Sequence_Length' was a string, convert to int
    # df['Sequence_Length'] = pd.to_numeric(df['Sequence_Length'], errors='coerce')

    # Drop Sample_ID and Sequence as they are not needed for analysis
    df = df.drop(['Sample_ID', 'Sequence'], axis=1)

    print("\n--- Data after cleaning and preprocessing ---")
    df.info()
    print(df.head())
    return df

if __name__ == "__main__":
    cleaned_df = clean_data("/home/ubuntu/upload/synthetic_dna_dataset.csv")
    cleaned_df.to_csv("cleaned_synthetic_dna_dataset.csv", index=False)
    print("Cleaned data saved to cleaned_synthetic_dna_dataset.csv")

